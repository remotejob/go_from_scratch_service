docker build -t mygolangapp:using-alpine .

docker images "mygolangapp:*"


docker run mygolangapp:using-alpine


docker build -t mygolangapp:using-multistage -f Dockerfile.multi .

git remote set-url origin https://remotejob:<password>@github.com/remotejob/go_from_scratch_service




